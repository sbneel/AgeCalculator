import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { collection, addDoc, serverTimestamp } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { TRANSLATIONS, Language } from '../lib/translations';
import { playSound } from '../lib/soundEffects';

interface WithdrawModalProps {
  lang: Language;
  userId: string;
  username: string;
  currentPoints: number;
  onClose: () => void;
}

export const WithdrawModal: React.FC<WithdrawModalProps> = ({ 
  lang, userId, username, currentPoints, onClose 
}) => {
  const t = TRANSLATIONS[lang];
  const [amount, setAmount] = useState('');
  const [bkashNumber, setBkashNumber] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    
    const numAmount = Number(amount);
    if (!bkashNumber || bkashNumber.length < 11) {
      setError('Invalid bKash Number');
      return;
    }
    if (numAmount < 100) {
      setError(t.minWithdraw);
      return;
    }
    if (numAmount > currentPoints) {
      setError(t.insufficientPoints);
      return;
    }

    setLoading(true);
    try {
      await addDoc(collection(db, 'withdrawals'), {
        userId,
        username,
        amount: numAmount,
        bkashNumber,
        status: 'pending',
        createdAt: serverTimestamp()
      });
      playSound('success');
      onClose();
      alert(t.withdrawalSuccess);
    } catch (err) {
      setError('Something went wrong. Try again.');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-[120] bg-black/60 backdrop-blur-md flex items-center justify-center p-6"
      onClick={onClose}
    >
      <motion.div 
        initial={{ scale: 0.9, y: 20 }}
        animate={{ scale: 1, y: 0 }}
        exit={{ scale: 0.9, y: 20 }}
        className="bg-surface w-full max-w-sm rounded-[40px] p-8 shadow-2xl relative"
        onClick={e => e.stopPropagation()}
      >
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-black text-primary uppercase tracking-tighter">{t.withdraw}</h2>
          <button onClick={onClose} className="p-2 bg-surface-variant rounded-full">
             <img src="https://img.icons8.com/color/48/cancel.png" alt="close" className="w-5 h-5" />
          </button>
        </div>

        <div className="bg-primary/5 p-4 rounded-2xl mb-6 text-center">
           <p className="text-[10px] font-black uppercase opacity-40 mb-1">{t.totalPoints}</p>
           <p className="text-2xl font-black text-primary">{currentPoints.toLocaleString()}</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
           <div className="space-y-1">
             <label className="text-[10px] font-black uppercase opacity-40 ml-4">{t.bkashNumber}</label>
             <input 
               type="text" 
               value={bkashNumber}
               onChange={(e) => setBkashNumber(e.target.value.replace(/[^0-9]/g, ''))}
               className="m3-input w-full"
               placeholder="017XXXXXXXX"
             />
           </div>
           <div className="space-y-1">
             <label className="text-[10px] font-black uppercase opacity-40 ml-4">{t.amount}</label>
             <input 
               type="number" 
               value={amount}
               onChange={(e) => setAmount(e.target.value)}
               className="m3-input w-full"
               placeholder="Min 100"
             />
           </div>
           
           {error && <p className="text-red-500 text-[10px] font-bold text-center italic">{error}</p>}

           <button 
             type="submit" 
             disabled={loading}
             className="m3-button w-full !rounded-2xl py-4 flex items-center justify-center gap-2 mt-4"
           >
             {loading ? t.loading : (
               <>
                 <img src="https://img.icons8.com/color/48/get-cash.png" alt="cash" className="w-5 h-5 brightness-200" />
                 {t.withdraw}
               </>
             )}
           </button>
        </form>
      </motion.div>
    </motion.div>
  );
};
