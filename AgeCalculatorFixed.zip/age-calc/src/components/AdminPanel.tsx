import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { collection, addDoc, serverTimestamp, query, orderBy, onSnapshot, deleteDoc, doc, updateDoc, setDoc } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { TRANSLATIONS, Language } from '../lib/translations';
import { playSound } from '../lib/soundEffects';
import { cn } from '../lib/utils';

interface AdminPanelProps {
  lang: Language;
  onClose: () => void;
}

interface Video {
  id: string;
  title: string;
  imageUrl: string;
  description: string;
  redirectUrl?: string;
}

interface RedirectLink {
  id: string;
  url: string;
  createdAt: any;
}

interface Withdrawal {
  id: string;
  userId: string;
  username: string;
  amount: number;
  bkashNumber: string;
  status: 'pending' | 'accepted';
  createdAt: any;
}

type AdminTab = 'posts' | 'withdrawals' | 'settings' | 'links';

export const AdminPanel: React.FC<AdminPanelProps> = ({ lang, onClose }) => {
  const t = TRANSLATIONS[lang];
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [loginError, setLoginError] = useState('');
  const [activeTab, setActiveTab] = useState<AdminTab>('posts');

  // Blog Management State
  const [videos, setVideos] = useState<Video[]>([]);
  const [isAddingVideo, setIsAddingVideo] = useState(false);
  const [editingVideoId, setEditingVideoId] = useState<string | null>(null);
  const [newVideoTitle, setNewVideoTitle] = useState('');
  const [newVideoUrl, setNewVideoUrl] = useState('');
  const [newVideoDesc, setNewVideoDesc] = useState('');
  const [newPostRedirectUrl, setNewPostRedirectUrl] = useState('');

  // Withdrawal Management State
  const [withdrawals, setWithdrawals] = useState<Withdrawal[]>([]);

  // Settings Management State
  const [primaryColor, setPrimaryColor] = useState('#4338ca');
  const [surfaceColor, setSurfaceColor] = useState('#fafafa');
  const [textColor, setTextColor] = useState('#111827');
  const [calculateLink, setCalculateLink] = useState('');
  const [isLinkEnabled, setIsLinkEnabled] = useState(false);

  // Redirect Links State
  const [redirectLinks, setRedirectLinks] = useState<RedirectLink[]>([]);
  const [newRedirectUrl, setNewRedirectUrl] = useState('');
  const [isAddingLink, setIsAddingLink] = useState(false);
  const [editingLinkId, setEditingLinkId] = useState<string | null>(null);

  useEffect(() => {
    if (isLoggedIn && db) {
      // Listen to Posts
      const vQuery = query(collection(db, 'posts'), orderBy('createdAt', 'desc'));
      const vUnsubscribe = onSnapshot(vQuery, (snapshot) => {
        setVideos(snapshot.docs.map(d => ({ id: d.id, ...d.data() })) as Video[]);
      });

      // Listen to Withdrawals
      const wQuery = query(collection(db, 'withdrawals'), orderBy('createdAt', 'desc'));
      const wUnsubscribe = onSnapshot(wQuery, (snapshot) => {
        setWithdrawals(snapshot.docs.map(d => ({ id: d.id, ...d.data() })) as Withdrawal[]);
      });

      // Listen to Redirect Links
      const rQuery = query(collection(db, 'calculation_links'), orderBy('createdAt', 'desc'));
      const rUnsubscribe = onSnapshot(rQuery, (snapshot) => {
        setRedirectLinks(snapshot.docs.map(d => ({ id: d.id, ...d.data() })) as RedirectLink[]);
      });

      // Listen to Settings
      const sUnsubscribe = onSnapshot(doc(db, 'settings', 'global'), (doc) => {
        if (doc.exists()) {
          const data = doc.data();
          setPrimaryColor(data.primaryColor || '#4338ca');
          setSurfaceColor(data.surfaceColor || '#fafafa');
          setTextColor(data.textColor || '#111827');
          setCalculateLink(data.calculateLink || '');
          setIsLinkEnabled(data.isLinkEnabled || false);
        }
      });

      return () => {
        vUnsubscribe();
        wUnsubscribe();
        sUnsubscribe();
        rUnsubscribe();
      };
    }
  }, [isLoggedIn]);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (username === 'sbneeladmin' && password === 'neelbaba') {
      setIsLoggedIn(true);
      setLoginError('');
      playSound('success');
    } else {
      setLoginError(t.invalidAdmin);
      playSound('delete');
    }
  };

  const handleVideoSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newVideoTitle || !newVideoUrl || !db) return;

    try {
      if (editingVideoId) {
        await updateDoc(doc(db, 'posts', editingVideoId), {
          title: newVideoTitle,
          imageUrl: newVideoUrl,
          description: newVideoDesc,
          redirectUrl: newPostRedirectUrl,
          updatedAt: serverTimestamp()
        });
        setEditingVideoId(null);
      } else {
        await addDoc(collection(db, 'posts'), {
          title: newVideoTitle,
          imageUrl: newVideoUrl,
          description: newVideoDesc,
          redirectUrl: newPostRedirectUrl,
          createdAt: serverTimestamp()
        });
      }
      setNewVideoTitle('');
      setNewVideoUrl('');
      setNewVideoDesc('');
      setNewPostRedirectUrl('');
      setIsAddingVideo(false);
      playSound('success');
    } catch (err) { console.error(err); }
  };

  const handleSettingsSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!db) return;
    try {
      await setDoc(doc(db, 'settings', 'global'), {
        primaryColor,
        surfaceColor,
        textColor,
        calculateLink,
        isLinkEnabled,
        updatedAt: serverTimestamp()
      }, { merge: true });
      playSound('success');
      alert('Settings Saved');
    } catch (err) { console.error(err); }
  };

  const deleteVideo = async (id: string) => {
    if (!db) return;
    if (window.confirm(t.confirmDelete)) {
      await deleteDoc(doc(db, 'posts', id));
      playSound('delete');
    }
  };

  const updateWithdrawalStatus = async (id: string, status: 'accepted') => {
    if (!db) return;
    await updateDoc(doc(db, 'withdrawals', id), { status });
    playSound('success');
  };

  const deleteWithdrawal = async (id: string) => {
    if (!db) return;
    if (window.confirm(t.confirmDelete)) {
      await deleteDoc(doc(db, 'withdrawals', id));
      playSound('delete');
    }
  };

  const handleLinkSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newRedirectUrl || !db) return;

    try {
      if (editingLinkId) {
        await updateDoc(doc(db, 'calculation_links', editingLinkId), {
          url: newRedirectUrl,
          updatedAt: serverTimestamp()
        });
        setEditingLinkId(null);
      } else {
        await addDoc(collection(db, 'calculation_links'), {
          url: newRedirectUrl,
          createdAt: serverTimestamp()
        });
      }
      setNewRedirectUrl('');
      setIsAddingLink(false);
      playSound('success');
    } catch (err) { console.error(err); }
  };

  const deleteLink = async (id: string) => {
    if (!db) return;
    if (window.confirm(t.confirmDelete)) {
      await deleteDoc(doc(db, 'calculation_links', id));
      playSound('delete');
    }
  };

  if (!isLoggedIn) {
    return (
      <div className="fixed inset-0 z-[120] bg-surface flex flex-col items-center justify-center p-6 backdrop-blur-xl bg-surface/90">
        <motion.div initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} className="w-full max-w-sm space-y-8 text-center">
          <div className="space-y-2">
            <div className="bg-primary/20 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-4 backdrop-blur-xl">
              <img src="https://img.icons8.com/color/96/admin-settings-male.png" alt="admin" className="w-12 h-12" />
            </div>
            <h2 className="text-3xl font-black tracking-tighter text-primary">{t.adminLogin}</h2>
            <p className="text-xs uppercase tracking-[0.3em] font-bold opacity-40">{t.securityAccess}</p>
          </div>

          <form onSubmit={handleLogin} className="space-y-4">
            <div className="space-y-1 text-left">
              <label className="text-[10px] font-black uppercase opacity-40 ml-4">{t.username}</label>
              <input 
                type="text" value={username} onChange={e => setUsername(e.target.value)} 
                className="m3-input w-full" placeholder={t.adminUserPlaceholder} 
              />
            </div>
            <div className="space-y-1 text-left">
              <label className="text-[10px] font-black uppercase opacity-40 ml-4">{t.password}</label>
              <input 
                type="password" value={password} onChange={e => setPassword(e.target.value)} 
                className="m3-input w-full" placeholder="••••••••" 
              />
            </div>
            {loginError && <p className="text-red-500 text-xs font-bold">{loginError}</p>}
            <button type="submit" className="m3-button w-full !rounded-2xl py-4 flex items-center justify-center gap-2">
              <img src="https://img.icons8.com/color/48/login-rounded-right--v1.png" alt="login" className="w-5 h-5 brightness-200" />
              {t.login}
            </button>
          </form>

          <button onClick={onClose} className="text-xs font-bold opacity-40 hover:opacity-100 transition-opacity uppercase tracking-widest">
            {t.cancel}
          </button>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 z-[120] bg-surface flex flex-col p-4 overflow-y-auto backdrop-blur-xl bg-surface/95">
      <header className="flex justify-between items-center mb-6 pt-4">
        <div className="flex items-center gap-3">
           <div className="bg-primary/10 p-2 rounded-2xl">
              <img src="https://img.icons8.com/color/48/admin-settings-male.png" alt="admin" className="w-6 h-6" />
           </div>
           <div>
             <h2 className="text-xl font-black uppercase tracking-tighter text-primary">{t.admin}</h2>
             <p className="text-[10px] font-bold opacity-40">{t.adminSubtitle}</p>
           </div>
        </div>
        <button onClick={onClose} className="p-2 bg-surface-variant/40 rounded-full">
           <img src="https://img.icons8.com/color/48/cancel.png" alt="close" className="w-5 h-5" />
        </button>
      </header>

      {/* Tabs */}
      <div className="flex gap-2 mb-8 bg-surface-variant/20 p-1 rounded-2xl overflow-x-auto hide-scrollbar">
         {(['posts', 'withdrawals', 'links', 'settings'] as AdminTab[]).map(tab => (
           <button 
             key={tab}
             onClick={() => setActiveTab(tab)}
             className={cn(
               "flex-1 min-w-[80px] py-3 rounded-xl text-[10px] font-black uppercase tracking-tight transition-all",
               activeTab === tab ? "bg-primary text-on-primary shadow-lg" : "opacity-40"
             )}
           >
             {tab === 'posts' ? t.videos : tab === 'links' ? t.manageLinks : t[tab as keyof typeof t] || tab}
           </button>
         ))}
      </div>

      <div className="pb-24">
        {activeTab === 'posts' && (
          <div className="space-y-6">
            {isAddingVideo || editingVideoId ? (
              <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="m3-card space-y-4">
                 <h3 className="text-lg font-black">{editingVideoId ? t.edit : t.addVideo}</h3>
                 <form onSubmit={handleVideoSubmit} className="space-y-4">
                    <input type="text" value={newVideoTitle} onChange={e => setNewVideoTitle(e.target.value)} className="m3-input w-full" placeholder={t.videoPlaceholder} />
                    <input type="url" value={newVideoUrl} onChange={e => setNewVideoUrl(e.target.value)} className="m3-input w-full" placeholder={t.urlPlaceholder} />
                    <input type="url" value={newPostRedirectUrl} onChange={e => setNewPostRedirectUrl(e.target.value)} className="m3-input w-full" placeholder={t.postLink} />
                    <textarea value={newVideoDesc} onChange={e => setNewVideoDesc(e.target.value)} className="m3-input w-full min-h-[100px] resize-none" placeholder={t.descPlaceholder} />
                    <div className="flex gap-3">
                      <button type="submit" className="m3-button flex-1">{t.saveVideo}</button>
                      <button type="button" onClick={() => { setIsAddingVideo(false); setEditingVideoId(null); }} className="m3-button-secondary flex-1">{t.cancel}</button>
                    </div>
                 </form>
              </motion.div>
            ) : (
              <button 
                onClick={() => setIsAddingVideo(true)}
                className="m3-card !bg-primary text-on-primary flex items-center justify-center gap-3 py-6 mb-4 w-full shadow-xl shadow-primary/20"
              >
                <img src="https://img.icons8.com/color/48/plus--v1.png" alt="add" className="w-8 h-8 brightness-200" />
                <span className="text-xl font-black uppercase tracking-tight">{t.addVideo}</span>
              </button>
            )}

            <div className="space-y-3">
              {videos.map(video => (
                <div key={video.id} className="m3-card !bg-white/40 flex items-center justify-between gap-4">
                   <div className="flex-1 min-w-0 text-left">
                      <h5 className="font-black text-primary truncate">{video.title}</h5>
                      <p className="text-[10px] opacity-40 truncate">{video.imageUrl}</p>
                   </div>
                   <div className="flex gap-2">
                      <button onClick={() => { 
                        setEditingVideoId(video.id); 
                        setNewVideoTitle(video.title); 
                        setNewVideoUrl(video.imageUrl || ''); 
                        setNewVideoDesc(video.description); 
                        setNewPostRedirectUrl(video.redirectUrl || '');
                      }} className="p-2 bg-secondary/10 rounded-xl">
                        <img src="https://img.icons8.com/color/48/edit--v1.png" alt="edit" className="w-4 h-4" />
                      </button>
                      <button onClick={() => deleteVideo(video.id)} className="p-2 bg-red-500/10 rounded-xl">
                        <img src="https://img.icons8.com/color/48/delete-forever.png" alt="delete" className="w-4 h-4" />
                      </button>
                   </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {activeTab === 'withdrawals' && (
          <div className="space-y-4">
             {withdrawals.map(req => (
               <div key={req.id} className="m3-card !bg-white/60 space-y-4">
                  <div className="flex justify-between items-start">
                     <div className="text-left">
                        <p className="text-[10px] font-black uppercase opacity-40">{t.amount}</p>
                        <h4 className="text-xl font-black text-primary">{req.amount} {t.points}</h4>
                     </div>
                     <div className={cn(
                       "px-3 py-1 rounded-full text-[10px] font-black uppercase",
                       req.status === 'pending' ? "bg-amber-100 text-amber-700" : "bg-green-100 text-green-700"
                     )}>
                        {t[req.status]}
                     </div>
                  </div>
                  <div className="grid grid-cols-2 gap-4 text-left border-t border-black/5 pt-4">
                     <div>
                        <p className="text-[10px] font-black uppercase opacity-40">User</p>
                        <p className="text-xs font-bold truncate">@{req.username}</p>
                     </div>
                     <div>
                        <p className="text-[10px] font-black uppercase opacity-40">{t.bkashNumber}</p>
                        <p className="text-xs font-mono font-bold">{req.bkashNumber}</p>
                     </div>
                  </div>
                  <div className="flex gap-2 pt-2">
                     {req.status === 'pending' && (
                        <button onClick={() => updateWithdrawalStatus(req.id, 'accepted')} className="m3-button flex-1 py-3 text-[10px] !rounded-xl">Accept</button>
                     )}
                     <button onClick={() => deleteWithdrawal(req.id)} className="m3-button-secondary flex-1 py-3 text-[10px] !rounded-xl !bg-red-500/10 !text-red-500">Delete</button>
                  </div>
               </div>
             ))}
          </div>
        )}

        {activeTab === 'links' && (
          <div className="space-y-6">
            {isAddingLink || editingLinkId ? (
              <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="m3-card space-y-4">
                 <h3 className="text-lg font-black">{editingLinkId ? t.edit : t.addLink}</h3>
                 <form onSubmit={handleLinkSubmit} className="space-y-4 text-left">
                    <label className="text-[10px] font-black uppercase opacity-40 ml-4">{t.linkUrl}</label>
                    <input type="url" value={newRedirectUrl} onChange={e => setNewRedirectUrl(e.target.value)} className="m3-input w-full" placeholder="https://..." required />
                    <div className="flex gap-3">
                      <button type="submit" className="m3-button flex-1">{t.saveLink}</button>
                      <button type="button" onClick={() => { setIsAddingLink(false); setEditingLinkId(null); }} className="m3-button-secondary flex-1">{t.cancel}</button>
                    </div>
                 </form>
              </motion.div>
            ) : (
              <button 
                onClick={() => setIsAddingLink(true)}
                className="m3-card !bg-primary text-on-primary flex items-center justify-center gap-3 py-6 mb-4 w-full shadow-xl shadow-primary/20"
              >
                <img src="https://img.icons8.com/color/48/plus--v1.png" alt="add" className="w-8 h-8 brightness-200" />
                <span className="text-xl font-black uppercase tracking-tight">{t.addLink}</span>
              </button>
            )}

            <div className="space-y-3">
              <h4 className="text-[10px] font-black uppercase opacity-40 text-left ml-4 mb-2 tracking-widest">{t.linkList}</h4>
              {redirectLinks.map(link => (
                <div key={link.id} className="m3-card !bg-white/40 flex items-center justify-between gap-4">
                   <div className="flex-1 min-w-0 text-left">
                      <p className="font-bold text-primary truncate text-sm">{link.url}</p>
                   </div>
                   <div className="flex gap-2">
                      <button onClick={() => { setEditingLinkId(link.id); setNewRedirectUrl(link.url); }} className="p-2 bg-secondary/10 rounded-xl">
                        <img src="https://img.icons8.com/color/48/edit--v1.png" alt="edit" className="w-4 h-4" />
                      </button>
                      <button onClick={() => deleteLink(link.id)} className="p-2 bg-red-500/10 rounded-xl">
                        <img src="https://img.icons8.com/color/48/delete-forever.png" alt="delete" className="w-4 h-4" />
                      </button>
                   </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {activeTab === 'settings' && (
          <form onSubmit={handleSettingsSubmit} className="space-y-6">
             <div className="m3-card space-y-6">
                <h3 className="text-lg font-black uppercase tracking-tighter text-primary">{t.themeSettings}</h3>
                
                <div className="space-y-4">
                   <div className="space-y-1 text-left">
                     <label className="text-[10px] font-black uppercase opacity-40 ml-4">{t.primaryColor}</label>
                     <div className="flex gap-3">
                        <input type="color" value={primaryColor} onChange={e => setPrimaryColor(e.target.value)} className="w-12 h-12 rounded-xl cursor-pointer" />
                        <input type="text" value={primaryColor} onChange={e => setPrimaryColor(e.target.value)} className="m3-input flex-1 font-mono" />
                     </div>
                   </div>

                   <div className="space-y-1 text-left">
                     <label className="text-[10px] font-black uppercase opacity-40 ml-4">{t.surfaceColor}</label>
                     <div className="flex gap-3">
                        <input type="color" value={surfaceColor} onChange={e => setSurfaceColor(e.target.value)} className="w-12 h-12 rounded-xl cursor-pointer" />
                        <input type="text" value={surfaceColor} onChange={e => setSurfaceColor(e.target.value)} className="m3-input flex-1 font-mono" />
                     </div>
                   </div>

                   <div className="space-y-1 text-left">
                     <label className="text-[10px] font-black uppercase opacity-40 ml-4">{t.textColor}</label>
                     <div className="flex gap-3">
                        <input type="color" value={textColor} onChange={e => setTextColor(e.target.value)} className="w-12 h-12 rounded-xl cursor-pointer" />
                        <input type="text" value={textColor} onChange={e => setTextColor(e.target.value)} className="m3-input flex-1 font-mono" />
                     </div>
                   </div>

                   <div className="space-y-1 text-left">
                     <label className="text-[10px] font-black uppercase opacity-40 ml-4">{t.calculateLink}</label>
                     <input 
                       type="url" 
                       value={calculateLink} 
                       onChange={e => setCalculateLink(e.target.value)} 
                       className="m3-input w-full" 
                       placeholder="https://example.com" 
                     />
                   </div>

                   <div className="flex items-center justify-between bg-surface-variant/20 p-4 rounded-2xl">
                      <span className="text-xs font-black uppercase tracking-tight">{t.linkToggle}</span>
                      <button 
                        type="button"
                        onClick={() => setIsLinkEnabled(!isLinkEnabled)}
                        className={cn(
                          "w-12 h-6 rounded-full relative transition-colors",
                          isLinkEnabled ? "bg-primary" : "bg-outline/20"
                        )}
                      >
                         <motion.div 
                           animate={{ x: isLinkEnabled ? 26 : 4 }}
                           className="absolute top-1 w-4 h-4 bg-white rounded-full"
                         />
                      </button>
                   </div>
                </div>

                <div className="p-4 rounded-2xl bg-primary/5 space-y-2">
                   <p className="text-[10px] font-black uppercase opacity-40 mb-2">Preview</p>
                   <div className="flex gap-2">
                      <div className="w-full h-8 rounded-lg shadow-inner" style={{ backgroundColor: primaryColor }} />
                      <div className="w-full h-8 rounded-lg border border-black/5" style={{ backgroundColor: surfaceColor }} />
                      <div className="w-full h-8 rounded-lg border border-black/5" style={{ backgroundColor: textColor }} />
                   </div>
                </div>

                <button type="submit" className="m3-button w-full">{t.saveSettings}</button>
             </div>
          </form>
        )}
      </div>
    </div>
  );
};
