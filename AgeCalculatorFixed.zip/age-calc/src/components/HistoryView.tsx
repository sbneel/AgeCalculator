import { motion, AnimatePresence } from 'motion/react';
import { TRANSLATIONS, Language } from '../lib/translations';
import { playSound } from '../lib/soundEffects';

interface HistoryItem {
  id: string;
  name?: string;
  dob: string;
  years: number;
  months: number;
  days: number;
  zodiac: string;
  zodiacIcon?: string;
  createdAt: number;
}

interface HistoryViewProps {
  history: HistoryItem[];
  lang: Language;
  onClear: () => void;
  onDeleteItem: (id: string) => void;
}

export function HistoryView({ history, lang, onClear, onDeleteItem }: HistoryViewProps) {
  const t = TRANSLATIONS[lang];

  if (history.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center p-12 text-outline">
        <img src="https://img.icons8.com/color/96/time-machine.png" alt="history" className="w-16 h-16 mb-4 opacity-30" />
        <p>{t.noHistory}</p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center px-2">
        <h3 className="text-lg font-black uppercase tracking-tighter">{t.historyTitle}</h3>
        <button 
          onClick={() => {
            playSound('click');
            onClear();
          }} 
          className="text-primary font-bold text-xs"
        >
          {t.clearAll}
        </button>
      </div>
      <div className="space-y-3">
        <AnimatePresence mode="popLayout">
          {history.map((item, idx) => (
            <motion.div
              key={item.id}
              layout
              initial={{ x: -20, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              exit={{ x: 50, opacity: 0 }}
              className="m3-card !p-4 flex justify-between items-center group relative overflow-hidden bg-white/40 border border-white/20 hover:bg-white/60 transition-colors"
            >
              <div className="flex items-center gap-4">
                <div className="text-3xl bg-primary/5 p-3 rounded-2xl grayscale group-hover:grayscale-0 transition-all duration-500">
                  {item.zodiacIcon || '✨'}
                </div>
                <div>
                  <div className="font-black text-sm uppercase tracking-tight flex items-center gap-2">
                    {item.name || item.dob.split('T')[0]}
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] font-black text-primary px-1.5 py-0.5 bg-primary/5 rounded-md">
                      {item.zodiac}
                    </span>
                    <div className="text-[10px] font-bold opacity-40 uppercase tracking-widest">
                      {item.years}Y, {item.months}M, {item.days}D
                    </div>
                  </div>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <div className="text-right">
                   <div className="text-[10px] uppercase font-black opacity-40 flex items-center gap-1 justify-end tracking-widest">
                    <img src="https://img.icons8.com/color/48/clock--v1.png" alt="clock" className="w-3 h-3 grayscale" />
                    {new Date(item.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </div>
                  <div className="text-[9px] font-mono opacity-30">{new Date(item.createdAt).toLocaleDateString()}</div>
                </div>
                <button 
                  onClick={() => {
                    playSound('click');
                    onDeleteItem(item.id);
                  }}
                  className="p-2.5 text-red-500/40 hover:text-red-500 bg-red-500/5 hover:bg-red-500/10 rounded-xl transition-all"
                >
                  <img src="https://img.icons8.com/color/48/delete-forever.png" alt="delete" className="w-4 h-4 grayscale group-hover:grayscale-0" />
                </button>
              </div>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>
    </div>
  );
}
