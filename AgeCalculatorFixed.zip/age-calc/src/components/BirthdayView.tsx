import React, { useState } from 'react';
import { motion } from 'motion/react';
import { TRANSLATIONS, Language } from '../lib/translations';
import { AnimatePresence } from 'motion/react';
import { getNextBirthday } from '../lib/ageUtils';
import { cn } from '../lib/utils';
import { playSound } from '../lib/soundEffects';

interface Birthday {
  id: string;
  name: string;
  dob: string;
}

interface BirthdayViewProps {
  birthdays: Birthday[];
  lang: Language;
  onAdd: (name: string, dob: string) => void;
  onDelete: (id: string) => void;
  onEdit: (id: string, name: string, dob: string) => void;
}

export function BirthdayView({ birthdays, lang, onAdd, onDelete, onEdit }: BirthdayViewProps) {
  const t = TRANSLATIONS[lang];
  const [isAdding, setIsAdding] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [newName, setNewName] = useState('Friend');
  const [newDob, setNewDob] = useState(new Date().toISOString().split('T')[0]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newName || !newDob) return;
    
    if (editingId) {
      onEdit(editingId, newName, newDob);
      setEditingId(null);
    } else {
      onAdd(newName, newDob);
    }
    
    setNewName('');
    setNewDob('');
    setIsAdding(false);
  };

  const handleEditClick = (b: Birthday) => {
    playSound('click');
    setNewName(b.name);
    setNewDob(b.dob);
    setEditingId(b.id);
    setIsAdding(true);
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center px-4">
        <h3 className="text-xl font-black uppercase tracking-tighter text-primary">{t.birthdays}</h3>
        <button 
          onClick={() => {
            playSound('tab');
            setIsAdding(!isAdding);
            if (isAdding) setEditingId(null);
          }} 
          className="bg-primary/10 text-primary p-2.5 rounded-2xl hover:bg-primary/20 transition-all active:scale-90"
        >
          <img 
            src="https://img.icons8.com/color/96/plus--v1.png" 
            alt="plus" 
            referrerPolicy="no-referrer"
            className={cn("w-6 h-6 transition-transform duration-500", isAdding ? "rotate-45" : "rotate-0")} 
          />
        </button>
      </div>

      <AnimatePresence>
        {isAdding && (
          <motion.form 
            initial={{ height: 0, opacity: 0, y: -20 }}
            animate={{ height: 'auto', opacity: 1, y: 0 }}
            exit={{ height: 0, opacity: 0, y: -20 }}
            onSubmit={handleSubmit}
            className="m3-card !p-6 space-y-4 overflow-hidden border-none shadow-[0_20px_40px_-12px_rgba(103,80,164,0.15)] bg-white/60"
          >
            <input
              type="text"
              placeholder={t.namePlaceholder}
              className="m3-input !p-4 !text-base"
              value={newName}
              onChange={(e) => setNewName(e.target.value)}
              required
            />
            <input
              type="date"
              className="m3-input !p-4 !text-base"
              value={newDob}
              onChange={(e) => setNewDob(e.target.value)}
              required
            />
            <button type="submit" className="m3-button w-full shadow-2xl shadow-primary/20">
              {editingId ? t.edit : t.add}
            </button>
          </motion.form>
        )}
      </AnimatePresence>

      <div className="space-y-4 px-1">
        <AnimatePresence mode="popLayout">
          {birthdays.length === 0 && !isAdding && (
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 0.5 }}
              exit={{ opacity: 0 }}
              className="text-center py-16 italic font-medium opacity-60 flex flex-col items-center gap-3"
            >
              <div className="p-4 bg-outline/5 rounded-full">
                 <img src="https://img.icons8.com/color/96/calendar--v1.png" alt="calendar" className="w-10 h-10" />
              </div>
              {t.noHistory}
            </motion.div>
          )}
          {birthdays.map((b) => {
          const { date, daysLeft } = getNextBirthday(new Date(b.dob));
          return (
            <motion.div 
              key={b.id}
              layout
              initial={{ x: -20, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              exit={{ scale: 0.8, opacity: 0 }}
              className="m3-card !p-4 flex items-center justify-between group relative overflow-hidden bg-white/40 border border-white/20 hover:bg-white/60 transition-all duration-300"
            >
                <div className="flex items-center gap-4">
                  <div className="bg-primary/10 p-3 rounded-2xl text-primary transition-transform group-hover:scale-110">
                    <img src="https://img.icons8.com/color/96/birthday-cake.png" alt="cake" className="w-8 h-8" />
                  </div>
                  <div>
                    <div className="font-black text-sm uppercase tracking-tight text-on-surface">{b.name}</div>
                    <div className="text-[10px] font-bold opacity-40 uppercase tracking-widest flex items-center gap-1 mt-0.5">
                      <img src="https://img.icons8.com/color/48/calendar--v1.png" alt="cal" className="w-3 h-3 opacity-60" />
                      {date.toLocaleDateString(lang === 'bn' ? 'bn-BD' : 'en-US', { day: 'numeric', month: 'long' })}
                    </div>
                  </div>
                </div>
              <div className="flex items-center gap-4">
                <div className="text-right">
                  <div className="text-2xl font-black text-primary tracking-tighter leading-none">{daysLeft}</div>
                  <div className="text-[10px] uppercase font-black opacity-30 tracking-widest">{t.daysLeft}</div>
                </div>
                  <div className="flex flex-col gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                    <button 
                      onClick={() => handleEditClick(b)}
                      className="p-2 text-primary/60 hover:text-primary bg-primary/5 hover:bg-primary/10 rounded-xl transition-all"
                    >
                      <img src="https://img.icons8.com/color/48/edit--v1.png" alt="edit" className="w-4 h-4" />
                    </button>
                    <button 
                      onClick={() => {
                        playSound('click');
                        onDelete(b.id);
                      }}
                      className="p-2 text-red-500/60 hover:text-red-500 bg-red-500/5 hover:bg-red-500/10 rounded-xl transition-all"
                    >
                      <img src="https://img.icons8.com/color/48/delete-forever.png" alt="delete" className="w-4 h-4" />
                    </button>
                  </div>
              </div>
            </motion.div>
          );
        })}
        </AnimatePresence>
      </div>
    </div>
  );
}
