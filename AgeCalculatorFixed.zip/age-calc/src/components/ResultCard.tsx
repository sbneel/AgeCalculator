import { motion } from 'motion/react';
import { TRANSLATIONS, type Language } from '../lib/translations';

interface ResultCardProps {
  label: string;
  value: string | number;
  lang: Language;
  variant?: 'primary' | 'secondary' | 'tertiary';
}

export function ResultCard({ label, value, lang, variant = 'primary' }: ResultCardProps) {
  const styles = {
    primary: 'bg-primary-container/40 text-on-primary-container border-primary/10 shadow-primary/5',
    secondary: 'bg-secondary-container/40 text-on-secondary-container border-secondary/10 shadow-secondary/5',
    tertiary: 'bg-tertiary-container/40 text-on-tertiary-container border-tertiary/10 shadow-tertiary/5'
  }[variant];

  return (
    <motion.div
      initial={{ scale: 0.9, opacity: 0 }}
      animate={{ scale: 1, opacity: 1 }}
      whileHover={{ scale: 1.05, y: -4 }}
      transition={{ type: 'spring', stiffness: 300, damping: 20 }}
      className={`glass-card !p-5 flex flex-col items-center justify-center text-center ${styles}`}
    >
      <span className="text-[10px] uppercase font-black tracking-[0.2em] opacity-60 mb-2">{label}</span>
      <span className="text-xl font-black tracking-tight leading-tight">{value}</span>
    </motion.div>
  );
}
