import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { TRANSLATIONS, Language } from '../lib/translations';
import { playSound } from '../lib/soundEffects';

interface ConfirmDialogProps {
  isOpen: boolean;
  title: string;
  message?: string;
  onConfirm: () => void;
  onCancel: () => void;
  lang: Language;
}

export function ConfirmDialog({ isOpen, title, message, onConfirm, onCancel, lang }: ConfirmDialogProps) {
  const t = TRANSLATIONS[lang];

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-[200] bg-black/60 backdrop-blur-md flex items-center justify-center p-6"
          onClick={onCancel}
        >
          <motion.div
            initial={{ scale: 0.9, opacity: 0, y: 20 }}
            animate={{ scale: 1, opacity: 1, y: 0 }}
            exit={{ scale: 0.9, opacity: 0, y: 20 }}
            className="glass-card !bg-white/95 text-on-surface w-full max-w-xs p-8 shadow-[0_32px_64px_-16px_rgba(0,0,0,0.3)] space-y-6 border-none"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex flex-col items-center text-center space-y-4">
              <div className="w-20 h-20 bg-red-500/10 rounded-full flex items-center justify-center mb-2">
                <img src="https://img.icons8.com/color/96/error.png" alt="alert" className="w-12 h-12 animate-pulse" />
              </div>
              <div className="space-y-2">
                <h3 className="text-2xl font-black leading-tight tracking-tight text-red-600">
                  {title}
                </h3>
                {message && (
                  <p className="text-xs font-bold text-outline/70 leading-relaxed max-w-[200px] mx-auto">
                    {message}
                  </p>
                )}
              </div>
            </div>

            <div className="flex flex-col gap-3">
              <button
                onClick={() => {
                  playSound('click');
                  onConfirm();
                }}
                className="w-full bg-red-500 text-white font-black py-4 rounded-3xl hover:bg-red-600 transition-colors shadow-lg shadow-red-500/20 active:scale-95"
              >
                {t.delete}
              </button>
              <button
                onClick={() => {
                  playSound('click');
                  onCancel();
                }}
                className="w-full bg-surface-variant/50 text-on-surface-variant font-bold py-4 rounded-3xl hover:bg-surface-variant transition-colors active:scale-95"
              >
                {t.cancel}
              </button>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
