import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { collection, query, orderBy, onSnapshot } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { TRANSLATIONS, Language } from '../lib/translations';
import { playSound } from '../lib/soundEffects';

interface Post {
  id: string;
  title: string;
  imageUrl: string;
  description: string;
  redirectUrl?: string;
  createdAt: any;
}

interface VideoViewProps {
  lang: Language;
  onVideoViewed: () => void;
}

export const VideoView: React.FC<VideoViewProps> = ({ lang, onVideoViewed }) => {
  const t = TRANSLATIONS[lang];
  const [posts, setPosts] = useState<Post[]>([]);
  const [loading, setLoading] = useState(true);
  const [viewedIds, setViewedIds] = useState<Set<string>>(new Set());

  useEffect(() => {
    if (!db) {
      setLoading(false);
      return;
    }
    const q = query(collection(db, 'posts'), orderBy('createdAt', 'desc'));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const postData = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as Post[];
      setPosts(postData);
      setLoading(false);
    }, (error) => {
      console.error("Error fetching posts:", error);
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  // Intersection Observer to detect when a post is scrolled to
  const handleIntersection = (entries: IntersectionObserverEntry[]) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        const postId = entry.target.getAttribute('data-post-id');
        if (postId && !viewedIds.has(postId)) {
          setViewedIds(prev => new Set(prev).add(postId));
          onVideoViewed();
          playSound('success');
        }
      }
    });
  };

  useEffect(() => {
    const observer = new IntersectionObserver(handleIntersection, {
      threshold: 0.7 
    });

    const elements = document.querySelectorAll('.post-scroll-item');
    elements.forEach(el => observer.observe(el));

    return () => observer.disconnect();
  }, [posts]);

  return (
    <div className="h-screen w-full flex flex-col pt-4 overflow-hidden">
      <div className="flex items-center gap-3 mb-4 px-4 text-left">
        <div className="bg-primary/10 p-2 rounded-2xl">
          <img src="https://img.icons8.com/color/48/news.png" alt="blog" className="w-6 h-6" />
        </div>
        <div>
          <h2 className="text-2xl font-black uppercase tracking-tighter">{t.videos}</h2>
          <p className="text-[10px] font-black opacity-40 uppercase tracking-widest">Scroll to earn points</p>
        </div>
      </div>

      <div className="flex-1 overflow-y-scroll snap-y snap-mandatory hide-scrollbar pb-32 px-4">
        {loading ? (
          <div className="flex flex-col items-center justify-center py-20 opacity-50">
            <div className="w-10 h-10 border-4 border-primary border-t-transparent rounded-full animate-spin mb-4" />
            <p className="font-bold text-sm uppercase tracking-widest italic font-mono">{t.loading}</p>
          </div>
        ) : posts.length === 0 ? (
          <div className="m3-card !bg-surface-variant/30 text-center py-20 flex flex-col items-center gap-4">
            <img src="https://img.icons8.com/color/96/empty-box.png" alt="empty" className="w-20 h-20 opacity-30" />
            <p className="font-bold opacity-50 italic">{t.noVideos}</p>
          </div>
        ) : (
          <div className="space-y-6">
            <AnimatePresence>
              {posts.map((post, index) => (
                <motion.div
                  key={post.id}
                  data-post-id={post.id}
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: index * 0.1 }}
                  className="snap-start post-scroll-item min-h-[400px] mb-6"
                >
                  <div 
                    onClick={() => {
                      if (post.redirectUrl) {
                        window.open(post.redirectUrl, '_blank');
                      }
                      playSound('click');
                    }}
                    className="m3-card !bg-white/40 backdrop-blur-xl border border-white/20 overflow-hidden !p-0 shadow-xl h-full flex flex-col active:scale-[0.98] transition-transform cursor-pointer"
                  >
                    {post.imageUrl && (
                      <div className="w-full aspect-[16/9] overflow-hidden bg-black/5">
                        <img 
                          src={post.imageUrl} 
                          alt={post.title} 
                          className="w-full h-full object-cover transition-transform hover:scale-105 duration-700" 
                          referrerPolicy="no-referrer"
                          onError={(e) => {
                            (e.target as HTMLImageElement).src = 'https://images.unsplash.com/photo-1499750310107-5fef28a66643?q=80&w=2070&auto=format&fit=crop';
                          }}
                        />
                      </div>
                    )}
                    <div className="p-6 flex-1 text-left">
                      <div className="flex justify-between items-start mb-4">
                        <h3 className="text-xl font-black text-primary leading-tight flex-1 mr-2">{post.title}</h3>
                        <div className="bg-primary text-on-primary px-3 py-1 rounded-full text-[10px] font-black uppercase shrink-0">
                          +1 Point
                        </div>
                      </div>
                      {post.description && (
                        <div className="text-sm opacity-80 leading-relaxed font-medium whitespace-pre-wrap">
                          {post.description}
                        </div>
                      )}
                      
                      <div className="mt-6 pt-4 border-t border-black/5 flex items-center justify-between text-[10px] font-black uppercase opacity-40">
                         <span>Age Calculator SB Blog</span>
                         <span>{post.createdAt?.seconds ? new Date(post.createdAt.seconds * 1000).toLocaleDateString() : ''}</span>
                      </div>
                    </div>
                  </div>
                </motion.div>
              ))}
            </AnimatePresence>
            <div className="h-40" />
          </div>
        )}
      </div>
    </div>
  );
};
