import { useEffect, useState } from 'react';

declare global {
  interface Window {
    Telegram: any;
  }
}

export function useTelegram() {
  const [user, setUser] = useState<any>(null);
  const [webApp, setWebApp] = useState<any>(null);

  useEffect(() => {
    const tg = window.Telegram?.WebApp;
    if (tg) {
      tg.ready();
      tg.expand();
      setWebApp(tg);
      setUser(tg.initDataUnsafe?.user || {
        id: 12345678,
        first_name: 'Test',
        last_name: 'User',
        photo_url: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Lucky'
      });
    }
  }, []);

  return { user, webApp };
}
