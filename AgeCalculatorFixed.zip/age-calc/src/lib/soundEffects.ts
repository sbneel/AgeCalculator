
let audioContext: AudioContext | null = null;

function getAudioContext(): AudioContext {
  if (!audioContext) {
    audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
  }
  return audioContext;
}

type SoundType = 'click' | 'success' | 'delete' | 'tab' | 'celebrate' | 'result';

export const playSound = (type: SoundType) => {
  // We check storage here as a quick way or the app can check
  const isMuted = localStorage.getItem('age_sound_muted') === 'true';
  if (isMuted) return;

  const audioContext = getAudioContext();

  if (audioContext.state === 'suspended') {
    audioContext.resume();
  }

  const now = audioContext.currentTime;

  const playNote = (freq: number, start: number, duration: number, vol: number = 0.1, type: OscillatorType = 'sine') => {
    const oscillator = audioContext.createOscillator();
    const gainNode = audioContext.createGain();
    oscillator.type = type;
    oscillator.frequency.setValueAtTime(freq, start);
    gainNode.gain.setValueAtTime(vol, start);
    gainNode.gain.exponentialRampToValueAtTime(0.01, start + duration);
    oscillator.connect(gainNode);
    gainNode.connect(audioContext.destination);
    oscillator.start(start);
    oscillator.stop(start + duration);
  };

  switch (type) {
    case 'click':
      playNote(800, now, 0.1, 0.1);
      break;

    case 'tab':
      playNote(1000, now, 0.05, 0.05);
      break;

    case 'success':
      playNote(523.25, now, 0.1); // C5
      playNote(659.25, now + 0.1, 0.1); // E5
      playNote(783.99, now + 0.2, 0.2); // G5
      break;

    case 'result':
      playNote(400, now, 0.2, 0.1, 'triangle');
      playNote(600, now + 0.1, 0.2, 0.1, 'triangle');
      playNote(800, now + 0.2, 0.4, 0.1, 'triangle');
      break;

    case 'delete':
      playNote(300, now, 0.3, 0.1, 'sawtooth');
      playNote(150, now + 0.1, 0.2, 0.1, 'sawtooth');
      break;

    case 'celebrate':
      // Happy Birthday Melody snippet (C4 C4 D4 C4 F4 E4) - Extended
      const tempo = 0.25;
      const hb = [
        { f: 261.63, d: 0.2 }, // C4
        { f: 261.63, d: 0.1 }, // C4
        { f: 293.66, d: 0.3 }, // D4
        { f: 261.63, d: 0.3 }, // C4
        { f: 349.23, d: 0.3 }, // F4
        { f: 329.63, d: 0.6 }, // E4
        { f: 261.63, d: 0.2 }, // C4
        { f: 261.63, d: 0.1 }, // C4
        { f: 293.66, d: 0.3 }, // D4
        { f: 261.63, d: 0.3 }, // C4
        { f: 392.00, d: 0.3 }, // G4
        { f: 349.23, d: 0.6 }, // F4
      ];
      hb.forEach((note, i) => {
        playNote(note.f, now + i * tempo, note.d, 0.1);
      });
      break;
  }
};
