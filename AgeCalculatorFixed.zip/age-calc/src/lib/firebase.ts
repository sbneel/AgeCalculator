import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getFirestore, collection, addDoc, query, where, getDocs, orderBy, limit, Timestamp } from 'firebase/firestore';

import firebaseConfig from '../../firebase-applet-config.json';

// We use a try-catch because the config file might contain placeholders initially
let db: any = null;
let auth: any = null;

try {
  if (firebaseConfig && firebaseConfig.apiKey && firebaseConfig.apiKey !== "YOUR_API_KEY") {
    const app = initializeApp(firebaseConfig as any);
    db = getFirestore(app);
    auth = getAuth(app);
  }
} catch (e) {
  console.warn("Firebase not configured. Using local storage fallback.");
}

export { db, auth };

// Helpers for Firestore operations
export async function saveHistory(historyItem: any) {
  if (!db || !auth.currentUser) return null;
  return addDoc(collection(db, 'history'), {
    ...historyItem,
    userId: auth.currentUser.uid,
    serverTimestamp: Timestamp.now()
  });
}

export async function fetchHistory() {
  if (!db || !auth.currentUser) return [];
  const q = query(
    collection(db, 'history'), 
    where('userId', '==', auth.currentUser.uid),
    orderBy('createdAt', 'desc'),
    limit(20)
  );
  const snapshot = await getDocs(q);
  return snapshot.docs.map(d => ({ id: d.id, ...d.data() }));
}
