import { 
  differenceInYears, 
  differenceInMonths, 
  differenceInDays, 
  differenceInHours, 
  differenceInMinutes, 
  differenceInSeconds,
  differenceInWeeks,
  addYears,
  addMonths,
  isAfter,
  set
} from 'date-fns';

export interface AgeResult {
  years: number;
  months: number;
  days: number;
  totalWeeks: number;
  totalDays: number;
  totalHours: number;
  totalMinutes: number;
  totalSeconds: number;
}

export function calculateAge(dob: Date, now: Date = new Date()): AgeResult {
  const years = differenceInYears(now, dob);
  const dobPlusYears = addYears(dob, years);
  
  const months = differenceInMonths(now, dobPlusYears);
  const dobPlusMonths = addMonths(dobPlusYears, months);
  
  const days = differenceInDays(now, dobPlusMonths);

  return {
    years,
    months,
    days,
    totalWeeks: differenceInWeeks(now, dob),
    totalDays: differenceInDays(now, dob),
    totalHours: differenceInHours(now, dob),
    totalMinutes: differenceInMinutes(now, dob),
    totalSeconds: differenceInSeconds(now, dob),
  };
}

export function getNextBirthday(dob: Date, now: Date = new Date()): { date: Date; daysLeft: number } {
  let nextBday = set(dob, { year: now.getFullYear() });
  
  if (isAfter(now, nextBday)) {
    nextBday = addYears(nextBday, 1);
  }
  
  const daysLeft = differenceInDays(nextBday, now);
  
  return { date: nextBday, daysLeft };
}

export const ZODIAC_SIGNS = [
  { name: 'Aries', bEn: 'Aries', bBn: 'মেষ', traitEn: 'Bold, Ambitious', traitBn: 'সাহসী, উচ্চাভিলাষী', planetEn: 'Mars', planetBn: 'মঙ্গল', start: { m: 3, d: 21 }, end: { m: 4, d: 19 }, icon: '♈' },
  { name: 'Taurus', bEn: 'Taurus', bBn: 'বৃষ', traitEn: 'Reliable, Practical', traitBn: 'নির্ভরযোগ্য, ব্যবহারিক', planetEn: 'Venus', planetBn: 'শুক্র', start: { m: 4, d: 20 }, end: { m: 5, d: 20 }, icon: '♉' },
  { name: 'Gemini', bEn: 'Gemini', bBn: 'মিথুন', traitEn: 'Expressive, Curious', traitBn: 'প্রকাশভঙ্গি, কৌতূহলী', planetEn: 'Mercury', planetBn: 'বুধ', start: { m: 5, d: 21 }, end: { m: 6, d: 20 }, icon: '♊' },
  { name: 'Cancer', bEn: 'Cancer', bBn: 'কর্কট', traitEn: 'Intuitive, Emotional', traitBn: 'স্বজ্ঞাত, আবেগপ্রবণ', planetEn: 'Moon', planetBn: 'চাঁদ', start: { m: 6, d: 21 }, end: { m: 7, d: 22 }, icon: '♋' },
  { name: 'Leo', bEn: 'Leo', bBn: 'সিংহ', traitEn: 'Dramatic, Confident', traitBn: 'নাটকীয়, আত্মবিশ্বাসী', planetEn: 'Sun', planetBn: 'সূর্য', start: { m: 7, d: 23 }, end: { m: 8, d: 22 }, icon: '♌' },
  { name: 'Virgo', bEn: 'Virgo', bBn: 'কন্যা', traitEn: 'Loyal, Analytical', traitBn: 'বিশ্বস্ত, বিশ্লেষণী', planetEn: 'Mercury', planetBn: 'বুধ', start: { m: 8, d: 23 }, end: { m: 9, d: 22 }, icon: '♍' },
  { name: 'Libra', bEn: 'Libra', bBn: 'তুলা', traitEn: 'Social, Fair-minded', traitBn: 'সামাজিক, ন্যায়পরায়ণ', planetEn: 'Venus', planetBn: 'শুক্র', start: { m: 9, d: 23 }, end: { m: 10, d: 22 }, icon: '♎' },
  { name: 'Scorpio', bEn: 'Scorpio', bBn: 'বৃশ্চিক', traitEn: 'Passionate, Brave', traitBn: 'আবেগপ্রবণ, সাহসী', planetEn: 'Pluto', planetBn: 'প্লুটো', start: { m: 10, d: 23 }, end: { m: 11, d: 21 }, icon: '♏' },
  { name: 'Sagittarius', bEn: 'Sagittarius', bBn: 'ধনু', traitEn: 'Generous, Idealistic', traitBn: 'উদার, আদর্শবাদী', planetEn: 'Jupiter', planetBn: 'বৃহস্পতি', start: { m: 11, d: 22 }, end: { m: 12, d: 21 }, icon: '♐' },
  { name: 'Capricorn', bEn: 'Capricorn', bBn: 'মকর', traitEn: 'Responsible, Disciplined', traitBn: 'দায়িত্বশীল, সুশৃঙ্খল', planetEn: 'Saturn', planetBn: 'শনি', start: { m: 12, d: 22 }, end: { m: 1, d: 19 }, icon: '♑' },
  { name: 'Aquarius', bEn: 'Aquarius', bBn: 'কুম্ভ', traitEn: 'Progressive, Original', traitBn: 'প্রগতিশীল, মৌলিক', planetEn: 'Uranus', planetBn: 'ইউরেনাস', start: { m: 1, d: 20 }, end: { m: 2, d: 18 }, icon: '♒' },
  { name: 'Pisces', bEn: 'Pisces', bBn: 'মীন', traitEn: 'Compassionate, Artistic', traitBn: 'সহমর্মী, শৈল্পিক', planetEn: 'Neptune', planetBn: 'নেপচুন', start: { m: 2, d: 19 }, end: { m: 3, d: 20 }, icon: '♓' },
];

export const ZODIAC_COLORS: Record<string, string> = {
  'Aries': '#FF4B4B',
  'Taurus': '#4CAF50',
  'Gemini': '#FFEB3B',
  'Cancer': '#9E9E9E',
  'Leo': '#FFC107',
  'Virgo': '#795548',
  'Libra': '#E91E63',
  'Scorpio': '#800000',
  'Sagittarius': '#9C27B0',
  'Capricorn': '#2E7D32',
  'Aquarius': '#00BCD4',
  'Pisces': '#2196F3'
};

export function getZodiacSign(dob: Date) {
  const month = dob.getMonth() + 1;
  const day = dob.getDate();
  
  return ZODIAC_SIGNS.find(sign => {
    const startMatch = (month === sign.start.m && day >= sign.start.d);
    const endMatch = (month === sign.end.m && day <= sign.end.d);
    
    // Handle Capricorn split over year end
    if (sign.name === 'Capricorn') {
      return (month === 12 && day >= 22) || (month === 1 && day <= 19);
    }
    
    return startMatch || endMatch;
  }) || ZODIAC_SIGNS[9]; // Default to Capricorn if not found (shouldn't happen)
}
