import { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useTelegram } from './hooks/useTelegram';
import { TRANSLATIONS, type Language } from './lib/translations';
import { calculateAge, getZodiacSign, getNextBirthday, ZODIAC_COLORS } from './lib/ageUtils';
import { ResultCard } from './components/ResultCard';
import { HistoryView } from './components/HistoryView';
import { BirthdayView } from './components/BirthdayView';
import { VideoView } from './components/VideoView';
import { AdminPanel } from './components/AdminPanel';
import { WithdrawModal } from './components/WithdrawModal';
import { ConfirmDialog } from './components/ConfirmDialog';
import { cn } from './lib/utils';
import confetti from 'canvas-confetti';
import { playSound } from './lib/soundEffects';
import jsPDF from 'jspdf';
import * as htmlToImage from 'html-to-image';
import { doc, onSnapshot, setDoc, updateDoc, increment, serverTimestamp, collection, query, where, orderBy, limit } from 'firebase/firestore';
import { db } from './lib/firebase';

function UserWithdrawalsList({ lang, userId }: { lang: Language; userId: string }) {
  const [myWithdrawals, setMyWithdrawals] = useState<any[]>([]);
  const t = TRANSLATIONS[lang];

  useEffect(() => {
    if (db) {
      const q = query(collection(db, 'withdrawals'), where('userId', '==', userId), orderBy('createdAt', 'desc'), limit(5));
      const unsubscribe = onSnapshot(q, (snapshot) => {
        setMyWithdrawals(snapshot.docs.map((d) => ({ id: d.id, ...d.data() })));
      });
      return () => unsubscribe();
    }
  }, [userId]);

  if (myWithdrawals.length === 0) return null;

  return (
    <div className="space-y-2">
      {myWithdrawals.map((w) => (
        <div key={w.id} className="bg-white/40 border border-white/40 p-3 rounded-2xl flex items-center justify-between">
          <div className="text-left">
            <p className="text-[10px] font-black uppercase opacity-40">
              {w.createdAt?.seconds ? new Date(w.createdAt.seconds * 1000).toLocaleDateString() : '...'}
            </p>
            <p className="font-bold text-primary">{w.amount} {t.points}</p>
          </div>
          <div className={cn(
            "px-3 py-1 rounded-full text-[8px] font-black uppercase",
            w.status === 'pending' ? "bg-amber-100 text-amber-700" : "bg-green-100 text-green-700"
          )}>
            {t[w.status as keyof typeof t] || w.status}
          </div>
        </div>
      ))}
    </div>
  );
}

export default function App() {
  const { user, webApp } = useTelegram();
  const [lang, setLang] = useState<Language>('en');
  const [activeTab, setActiveTab] = useState<'calculate' | 'history' | 'birthdays' | 'videos'>('calculate');
  const [dob, setDob] = useState('1998-05-25');
  const [tob, setTob] = useState('10:30');
  const [results, setResults] = useState<any>(null);
  const [liveDate, setLiveDate] = useState(new Date().toISOString().split('T')[0]);
  const [history, setHistory] = useState<any[]>([]);
  const [birthdays, setBirthdays] = useState<any[]>([]);
  const [isOnline, setIsOnline] = useState(true);
  const [showCelebration, setShowCelebration] = useState(false);
  const [showProfile, setShowProfile] = useState(false);
  const [showAdmin, setShowAdmin] = useState(false);
  const [showWithdrawModal, setShowWithdrawModal] = useState(false);
  const [isSoundMuted, setIsSoundMuted] = useState(localStorage.getItem('age_sound_muted') === 'true');
  const [confirmData, setConfirmData] = useState<{ isOpen: boolean; title: string; message?: string; action: () => void } | null>(null);
  const [redirectLinks, setRedirectLinks] = useState<any[]>([]);
  const resultsRef = useRef<HTMLDivElement>(null);

  const t = TRANSLATIONS[lang];

  // Theme Sync
  const [globalSettings, setGlobalSettings] = useState<any>(null);
  useEffect(() => {
    if (db) {
      const unsubscribe = onSnapshot(doc(db, 'settings', 'global'), (snapshot) => {
        if (snapshot.exists()) {
          const data = snapshot.data();
          setGlobalSettings(data);
          if (data.primaryColor) {
            document.documentElement.style.setProperty('--color-primary', data.primaryColor);
            document.documentElement.style.setProperty('--color-primary-container', `${data.primaryColor}20`);
          }
          if (data.surfaceColor) {
            document.documentElement.style.setProperty('--color-surface', data.surfaceColor);
          }
          if (data.textColor) {
            document.documentElement.style.setProperty('--color-on-surface', data.textColor);
          }
        }
      });
      return () => unsubscribe();
    }
  }, []);

  // Redirect Links Sync
  useEffect(() => {
    if (db) {
      const q = query(collection(db, 'calculation_links'), orderBy('createdAt', 'desc'));
      const unsubscribe = onSnapshot(q, (snapshot) => {
        setRedirectLinks(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
      });
      return () => unsubscribe();
    }
  }, []);

  // Points Sync
  const [userPoints, setUserPoints] = useState(0);
  useEffect(() => {
    if (db && user?.id) {
      const userRef = doc(db, 'users', user.id.toString());
      const unsubscribe = onSnapshot(userRef, (snapshot) => {
        if (snapshot.exists()) {
          setUserPoints(snapshot.data().points || 0);
        } else {
          setDoc(userRef, { 
            username: user.username || '', 
            points: 0,
            lastActive: serverTimestamp() 
          });
        }
      });
      return () => unsubscribe();
    }
  }, [user]);

  const addPoints = async (amount: number) => {
    if (!db || !user?.id) return;
    try {
      const userRef = doc(db, 'users', user.id.toString());
      await updateDoc(userRef, {
        points: increment(amount),
        lastActive: serverTimestamp()
      });
    } catch (err) {
      console.error("Failed to add points:", err);
    }
  };

  // Load from localStorage as fallback for Firebase
  useEffect(() => {
    const savedHistory = localStorage.getItem('age_history');
    if (savedHistory) setHistory(JSON.parse(savedHistory));
    
    const savedBirthdays = localStorage.getItem('age_birthdays');
    if (savedBirthdays) setBirthdays(JSON.parse(savedBirthdays));
  }, []);

  // Update online status
  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  const triggerConfetti = () => {
    const duration = 3 * 1000;
    const animationEnd = Date.now() + duration;
    const defaults = { startVelocity: 30, spread: 360, ticks: 60, zIndex: 100 };

    function randomInRange(min: number, max: number) {
      return Math.random() * (max - min) + min;
    }

    const interval: any = setInterval(function() {
      const timeLeft = animationEnd - Date.now();

      if (timeLeft <= 0) {
        return clearInterval(interval);
      }

      const particleCount = 50 * (timeLeft / duration);
      confetti({ ...defaults, particleCount, origin: { x: randomInRange(0.1, 0.3), y: Math.random() - 0.2 } });
      confetti({ ...defaults, particleCount, origin: { x: randomInRange(0.7, 0.9), y: Math.random() - 0.2 } });
    }, 250);
  };

  const handleCalculate = () => {
    if (!dob) return;
    
    // Play sound and haptic
    playSound('result');
    webApp?.HapticFeedback?.impactOccurred('medium');

    const birthDate = new Date(tob ? `${dob}T${tob}` : dob);
    const referenceDate = new Date(liveDate);
    const age = calculateAge(birthDate, referenceDate);
    const zodiac = getZodiacSign(birthDate);
    const nextBday = getNextBirthday(birthDate, referenceDate);
    
    const birthDayName = birthDate.toLocaleDateString(lang === 'bn' ? 'bn-BD' : 'en-US', { weekday: 'long' });

    const newResult = {
      ...age,
      zodiac: lang === 'bn' ? zodiac?.bBn : zodiac?.bEn,
      zodiacId: zodiac?.name, 
      zodiacTrait: lang === 'bn' ? zodiac?.traitBn : zodiac?.traitEn,
      planet: lang === 'bn' ? zodiac?.planetBn : zodiac?.planetEn,
      zodiacIcon: zodiac?.icon,
      nextBirthday: nextBday.date,
      daysToNext: nextBday.daysLeft,
      birthDay: birthDayName,
      moonMonths: (age.totalDays / 29.53059).toFixed(1),
      breaths: (age.totalDays * 24 * 60 * 16).toLocaleString(lang === 'bn' ? 'bn-BD' : 'en-US'), // ~16 breaths/min
      heartbeats: (age.totalDays * 24 * 60 * 80).toLocaleString(lang === 'bn' ? 'bn-BD' : 'en-US'), // ~80 bpm
      sleepYears: (age.years / 3).toFixed(1) // Assuming 1/3 of life slept
    };
    
    setResults(newResult);
    addPoints(1);
    
    // Redirect if enabled
    if (globalSettings?.isLinkEnabled) {
      if (redirectLinks.length > 0) {
        const randomLink = redirectLinks[Math.floor(Math.random() * redirectLinks.length)];
        window.open(randomLink.url, '_blank');
      } else if (globalSettings?.calculateLink) {
        window.open(globalSettings.calculateLink, '_blank');
      }
    }
    
    // Apply Dynamic Theme (Fallback to Zodiac if global settings empty)
    if (zodiac?.name && !document.documentElement.style.getPropertyValue('--color-primary')) {
      const color = ZODIAC_COLORS[zodiac.name];
      const root = document.documentElement;
      root.style.setProperty('--color-primary', color);
      root.style.setProperty('--color-primary-container', `${color}20`); // 12% opacity
    }

    // Check if birthday is today (relative to referenceDate)
    if (birthDate.getDate() === referenceDate.getDate() && birthDate.getMonth() === referenceDate.getMonth()) {
      setShowCelebration(true);
      playSound('celebrate');
      triggerConfetti();
    }

const historyItem = {
      id: Math.random().toString(36).substr(2, 9),
      dob: dob,
      ...age,
      zodiac: `${zodiac?.icon} ${lang === 'bn' ? zodiac?.bBn : zodiac?.bEn}`,
      zodiacIcon: zodiac?.icon,
      createdAt: Date.now()
    };
    
    const newHistory = [historyItem, ...history.slice(0, 19)];
    setHistory(newHistory);
    localStorage.setItem('age_history', JSON.stringify(newHistory));
  };

  // Live Counter Effect
  useEffect(() => {
    if (!results || activeTab !== 'calculate') return;

    const timer = setInterval(() => {
      setResults((prev: any) => {
        if (!prev) return prev;
        return {
          ...prev,
          totalSeconds: prev.totalSeconds + 1
        };
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [results, activeTab]);

  const handleAddBirthday = (name: string, date: string) => {
    playSound('success');
    webApp?.HapticFeedback?.notificationOccurred('success');
    const newBday = {
      id: Math.random().toString(36).substr(2, 9),
      name,
      dob: date
    };
    const newBirthdays = [newBday, ...birthdays];
    setBirthdays(newBirthdays);
    localStorage.setItem('age_birthdays', JSON.stringify(newBirthdays));
  };

  const handleEditBirthday = (id: string, name: string, date: string) => {
    playSound('click');
    webApp?.HapticFeedback?.notificationOccurred('success');
    const newBirthdays = birthdays.map(b => b.id === id ? { ...b, name, dob: date } : b);
    setBirthdays(newBirthdays);
    localStorage.setItem('age_birthdays', JSON.stringify(newBirthdays));
  };

  const handleDeleteBirthday = (id: string) => {
    setConfirmData({
      isOpen: true,
      title: t.confirmDelete,
      message: t.deleteMessage,
      action: () => {
        const newBirthdays = birthdays.filter(b => b.id !== id);
        setBirthdays(newBirthdays);
        localStorage.setItem('age_birthdays', JSON.stringify(newBirthdays));
        playSound('delete');
        webApp?.HapticFeedback?.impactOccurred('light');
        setConfirmData(null);
      }
    });
  };

  const clearHistory = () => {
    setConfirmData({
      isOpen: true,
      title: t.confirmClear,
      message: t.clearMessage,
      action: () => {
        setHistory([]);
        localStorage.removeItem('age_history');
        playSound('delete');
        webApp?.HapticFeedback?.notificationOccurred('success');
        setConfirmData(null);
      }
    });
  };

  const handleDeleteHistoryItem = (id: string) => {
    setConfirmData({
      isOpen: true,
      title: t.confirmDelete,
      message: t.deleteMessage,
      action: () => {
        const newHistory = history.filter(item => item.id !== id);
        setHistory(newHistory);
        localStorage.setItem('age_history', JSON.stringify(newHistory));
        playSound('delete');
        webApp?.HapticFeedback?.impactOccurred('light');
        setConfirmData(null);
      }
    });
  };

  const handleDownloadPdf = async () => {
    if (!results) return;
    playSound('click');
    
    try {
      const doc = new jsPDF('p', 'mm', 'a4');
      const primaryColor = getComputedStyle(document.documentElement).getPropertyValue('--color-primary').trim() || '#4338ca';
      
      // Header
      doc.setFillColor(primaryColor);
      doc.rect(0, 0, 210, 40, 'F');
      
      doc.setTextColor(255, 255, 255);
      doc.setFontSize(24);
      doc.setFont('helvetica', 'bold');
      doc.text(t.title, 20, 25);
      
      // Content
      doc.setTextColor(0, 0, 0);
      doc.setFontSize(16);
      doc.text(`User: ${user?.first_name || 'Guest'}`, 20, 60);
      doc.setFontSize(12);
      doc.text(`Date: ${new Date().toLocaleDateString()}`, 20, 70);
      
      doc.setDrawColor(200, 200, 200);
      doc.line(20, 75, 190, 75);
      
      // Results Grid
      doc.setFontSize(14);
      doc.setFont('helvetica', 'bold');
      doc.text(t.results, 20, 90);
      
      doc.setFont('helvetica', 'normal');
      doc.text(`${t.years}:`, 20, 105);
      doc.text((results.years ?? 0).toString(), 60, 105);
      
      doc.text(`${t.months}:`, 20, 115);
      doc.text((results.months ?? 0).toString(), 60, 115);
      
      doc.text(`${t.days}:`, 20, 125);
      doc.text((results.days ?? 0).toString(), 60, 125);
      
      doc.text(`${t.zodiac}:`, 20, 135);
      doc.text(`${results.zodiacIcon || ''} ${results.zodiac || ''}`, 60, 135);
      
      doc.text(`${t.nextBirthday}:`, 20, 145);
      doc.text(`${results.daysToNext ?? 0} ${t.daysLeft}`, 60, 145);

      // Statistics
      doc.setFont('helvetica', 'bold');
      doc.text(t.stats, 20, 165);
      doc.setFont('helvetica', 'normal');
      doc.setFontSize(10);
      doc.text(`${t.totalBreaths}: ${results.breaths || '0'}`, 20, 175);
      doc.text(`${t.totalHeartbeats}: ${results.heartbeats || '0'}`, 20, 185);
      doc.text(`${t.totalSleep}: ${results.sleepYears || '0'} ${t.years}`, 20, 195);
      
      // Footer
      doc.setTextColor(150, 150, 150);
      doc.setFontSize(10);
      doc.text("Generated by Age Calculator SB Telegram Mini App", 105, 280, { align: 'center' });
      
      doc.save(`${user?.first_name || 'User'}_Age_Report.pdf`);
      
      if (webApp?.showConfirm) {
        webApp.showConfirm(t.downloadPdf);
      }
    } catch (error) {
      console.error("PDF generation failed:", error);
    }
  };

  const toggleSound = () => {
    const newVal = !isSoundMuted;
    setIsSoundMuted(newVal);
    localStorage.setItem('age_sound_muted', String(newVal));
    if (!newVal) {
      playSound('click');
    }
  };

  const zodiacColor = results?.zodiacId ? ZODIAC_COLORS[results.zodiacId as keyof typeof ZODIAC_COLORS] ?? '#4338ca' : '#4338ca';

  return (
    <div className="min-h-screen bg-surface flex flex-col max-w-lg mx-auto overflow-hidden text-on-surface relative">
      {/* Dynamic Background Pattern */}
      <div className="fixed inset-0 pointer-events-none z-0 overflow-hidden">
        <div 
          className="absolute top-[-10%] left-[-10%] w-[60%] h-[60%] rounded-full blur-[120px] animate-pulse transition-colors duration-1000" 
          style={{ backgroundColor: `${zodiacColor}20` }} 
        />
        <div 
          className="absolute bottom-[-10%] right-[-10%] w-[60%] h-[60%] rounded-full blur-[120px] animate-pulse delay-1000 transition-colors duration-1000" 
          style={{ backgroundColor: `${zodiacColor}30` }} 
        />
        
        {/* Floating Glass Particles */}
        <motion.div 
          animate={{ y: [0, -20, 0], x: [0, 10, 0] }}
          transition={{ duration: 8, repeat: Infinity, ease: "easeInOut" }}
          className="absolute top-[20%] right-[15%] w-12 h-12 rounded-full bg-white/20 blur-md border border-white/40"
        />
        <motion.div 
          animate={{ y: [0, 30, 0], x: [0, -15, 0] }}
          transition={{ duration: 12, repeat: Infinity, ease: "easeInOut", delay: 1 }}
          className="absolute bottom-[25%] left-[10%] w-16 h-16 rounded-full blur-lg"
          style={{ backgroundColor: `${zodiacColor}10` }}
        />
        <motion.div 
          animate={{ scale: [1, 1.2, 1] }}
          transition={{ duration: 10, repeat: Infinity, ease: "easeInOut" }}
          className="absolute top-[40%] left-[5%] w-8 h-8 rounded-full bg-tertiary/5 blur-md"
        />
      </div>
      
  {/* Header */}
      <header className="fixed top-0 left-0 right-0 z-[100] bg-surface/80 backdrop-blur-xl border-b border-black/5 px-6 py-4 flex justify-between items-center transition-all duration-300">
        <div className="flex items-center gap-3">
          <button 
            onClick={() => {
              playSound('click');
              setShowProfile(true);
              webApp?.HapticFeedback?.selectionChanged();
            }}
            className="w-12 h-12 rounded-2xl border-4 border-primary/10 overflow-hidden bg-primary-container flex items-center justify-center p-0.5 group-hover:border-primary/40 transition-all duration-300 shadow-lg active:scale-95"
          >
            {user?.photo_url ? (
              <img src={user.photo_url} alt="Profile" className="w-full h-full rounded-full object-cover" referrerPolicy="no-referrer" />
            ) : (
              <img src="https://img.icons8.com/color/96/user.png" alt="user" className="w-6 h-6 opacity-70" />
            )}
          </button>
          <div>
            <h1 className="text-sm font-black leading-none mb-1 text-on-surface">
              {user?.first_name}
            </h1>
            <div className="flex items-center gap-1.5 leading-none">
              <span className="text-[9px] font-black text-primary/70 tracking-widest uppercase">
                {userPoints.toLocaleString()} {t.points}
              </span>
            </div>
          </div>
        </div>
        
        <div className="flex items-center gap-2">
          <button 
            onClick={() => {
              setLang(lang === 'en' ? 'bn' : 'en');
              playSound('tab');
              webApp?.HapticFeedback?.selectionChanged();
            }}
            className="bg-secondary-container text-on-secondary-container px-3 py-1.5 rounded-2xl text-[10px] font-black flex items-center gap-1 shadow-sm active:scale-95 transition-transform"
          >
            {lang === 'en' ? 'BN' : 'EN'}
          </button>
          <button 
            onClick={() => setShowAdmin(true)}
            className="bg-primary/10 text-primary p-2.5 rounded-2xl active:scale-95 transition-transform shadow-sm"
          >
            <img src="https://img.icons8.com/color/48/admin-settings-male.png" alt="admin" className="w-5 h-5" />
          </button>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="flex-1 overflow-y-auto px-6 pt-24 pb-32 space-y-8 scroll-smooth z-10">
        <AnimatePresence mode="wait">
          {activeTab === 'calculate' && (
            <motion.div
              key="calculate"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="space-y-6"
            >
              {/* Input Section */}
              <section className="space-y-3">
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-1">
                    <label className="text-[10px] uppercase font-black text-outline/60 tracking-wider pl-1">
                      {t.liveDay}
                    </label>
                    <input 
                      type="date" 
                      className="m3-input !p-3 !text-sm border-primary/20"
                      value={liveDate}
                      onChange={(e) => setLiveDate(e.target.value)}
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-[10px] uppercase font-black text-outline/60 tracking-wider pl-1">
                      {t.dob}
                    </label>
                    <input 
                      type="date" 
                      className="m3-input !p-3 !text-sm border-primary/30"
                      value={dob}
                      placeholder={t.birthdayLabel}
                      onChange={(e) => setDob(e.target.value)}
                    />
                  </div>
                </div>
                <div className="space-y-1">
                  <label className="text-[10px] uppercase font-black text-outline/60 tracking-wider pl-1">
                    {t.timeOfBirth}
                  </label>
                  <input 
                    type="time" 
                    className="m3-input !p-3 !text-sm border-primary/10" 
                    value={tob}
                    placeholder="12:00"
                    onChange={(e) => setTob(e.target.value)}
                  />
                </div>
                <button 
                  onClick={handleCalculate}
                  className="m3-button w-full !py-3.5 mt-2 group outline-none"
                >
                  <img src="https://img.icons8.com/color/96/calculator--v1.png" alt="calc" referrerPolicy="no-referrer" className="w-5 h-5 mr-2 group-hover:rotate-12 transition-transform" /> 
                  {t.calculateBtn}
                </button>
              </section>

              {/* Results Section */}
              {results && (
                <motion.section 
                  ref={resultsRef}
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="space-y-6 pb-10"
                >
                  <div className="flex justify-between items-center px-2">
                    <h2 className="text-xl font-black uppercase tracking-tighter">{t.results}</h2>
                    <button 
                      onClick={handleDownloadPdf}
                      className="bg-primary/10 p-2 rounded-xl active:scale-90 transition-transform flex items-center justify-center gap-2 px-3"
                    >
                      <img src="https://img.icons8.com/color/48/print.png" alt="print" className="w-5 h-5" />
                      <span className="text-[10px] font-bold uppercase">{t.downloadPdf}</span>
                    </button>
                  </div>

                  {/* Primary Age Display */}
                  <motion.div 
                    initial={{ scale: 0.9, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    className="m3-card !bg-primary text-on-primary flex flex-col items-center shadow-2xl relative overflow-hidden group border-none"
                  >
                    <div className="absolute top-0 right-0 p-4 opacity-10 scale-150 rotate-12 group-hover:rotate-45 transition-transform duration-1000 grayscale brightness-200">
                      <img src="https://img.icons8.com/color/96/calculator--v1.png" alt="calc" className="w-24 h-24" />
                    </div>
                    <span className="text-[10px] uppercase font-black tracking-widest opacity-70 mb-2 relative z-10">{t.title} - {t.results}</span>
                    <div className="flex items-baseline gap-2 relative z-10 transition-transform duration-500 group-hover:scale-110">
                      <span className="text-6xl font-black tracking-tighter">{results.years}</span>
                      <span className="text-xl opacity-80 font-bold">{t.years}</span>
                    </div>
                    <p className="text-[10px] font-medium opacity-60 mt-3 relative z-10 max-w-[240px] text-center italic leading-relaxed">
                      {lang === 'en' 
                        ? "Every life is a masterpiece of time. Celebrate every moment, for every year is a gift well traveled."
                        : "প্রতিটি জীবন সময়ের একটি অনবদ্য শিল্পকর্ম। প্রতিটি মুহূর্ত উদযাপন করুন, কারণ প্রতিটি বছর একটি সুন্দর ভ্রমণের উপহার।"}
                    </p>
                    <div className="flex gap-4 mt-4 opacity-90 relative z-10 font-bold bg-white/10 px-4 py-1 rounded-full backdrop-blur-md">
                      <span>{results.months} {t.months}</span>
                      <span className="opacity-40">|</span>
                      <span>{results.days} {t.days}</span>
                    </div>
                  </motion.div>

                  {/* Life Progress */}
                  <motion.div 
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.2 }}
                    className="m3-card !bg-white/40 backdrop-blur-xl border border-white/20"
                  >
                    <div className="flex justify-between items-end mb-3">
                      <span className="text-[10px] font-black uppercase tracking-[0.2em] opacity-60">{t.lifeProgress}</span>
                      <span className="text-xl font-black text-primary">{Math.min(100, Math.round((results.years / 80) * 100))}%</span>
                    </div>
                    <div className="w-full h-4 bg-primary/5 rounded-full overflow-hidden p-0.5 border border-primary/5">
                      <motion.div 
                        initial={{ width: 0 }}
                        animate={{ width: `${Math.min(100, (results.years / 80) * 100)}%` }}
                        transition={{ duration: 2, ease: [0.34, 1.56, 0.64, 1] }}
                        className="h-full bg-primary rounded-full shadow-[0_0_15px_rgba(103,80,164,0.4)]"
                      />
                    </div>
                    <p className="text-[10px] mt-4 opacity-70 text-center font-medium italic">
                      * {t.lifeExpectancy}
                    </p>
                  </motion.div>

                  {/* Analysis Cards */}
                  <motion.div 
                    initial="hidden"
                    animate="visible"
                    variants={{
                      hidden: { opacity: 0 },
                      visible: {
                        opacity: 1,
                        transition: { staggerChildren: 0.1, delayChildren: 0.3 }
                      }
                    }}
                    className="grid grid-cols-2 gap-4"
                  >
                    <motion.div variants={{ hidden: { y: 20, opacity: 0 }, visible: { y: 0, opacity: 1 } }}>
                      <ResultCard label={t.zodiac} value={`${results.zodiacIcon} ${results.zodiac}`} lang={lang} />
                    </motion.div>
                    <motion.div variants={{ hidden: { y: 20, opacity: 0 }, visible: { y: 0, opacity: 1 } }}>
                       <ResultCard label={t.birthDay} value={results.birthDay} lang={lang} variant="secondary" />
                    </motion.div>
                    <motion.div variants={{ hidden: { y: 20, opacity: 0 }, visible: { y: 0, opacity: 1 } }} className="col-span-2">
                      <ResultCard label={t.nextBirthday} value={`${results.daysToNext} ${t.daysLeft}`} lang={lang} variant="tertiary" />
                    </motion.div>
                  </motion.div>

                  {/* Life Stats Analysis */}
                  <motion.div 
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.4 }}
                    className="m3-card !bg-white/40 backdrop-blur-xl border border-white/20 space-y-6"
                  >
                    <div className="flex items-center gap-3">
                       <div className="bg-primary/10 p-2 rounded-2xl">
                          <img src="https://img.icons8.com/color/48/shining-stars.png" alt="stats" className="w-5 h-5" />
                       </div>
                       <h4 className="font-black text-xs uppercase tracking-[0.2em] text-primary">{t.stats}</h4>
                    </div>
                    <div className="space-y-3">
                      {[
                        { label: t.totalBreaths, value: results.breaths, icon: '💨' },
                        { label: t.totalHeartbeats, value: results.heartbeats, icon: '❤️' },
                        { label: t.totalSleep, value: `${results.sleepYears} ${t.years}`, icon: '😴' },
                        { label: t.moonMonths, value: results.moonMonths, icon: '🌙' }
                      ].map((stat, i) => (
                        <motion.div 
                          key={i}
                          initial={{ x: -20, opacity: 0 }}
                          animate={{ x: 0, opacity: 1 }}
                          transition={{ delay: 0.5 + (i * 0.1) }}
                          className="flex justify-between items-center bg-white/50 backdrop-blur-md p-4 rounded-3xl border border-white/40 hover:bg-white/80 transition-all group"
                        >
                          <div className="flex items-center gap-3">
                            <span className="text-xl grayscale group-hover:grayscale-0 transition-all">{stat.icon}</span>
                            <span className="text-[10px] font-black uppercase opacity-60 tracking-wider font-sans">{stat.label}</span>
                          </div>
                          <span className="font-black text-primary text-sm font-mono">{stat.value}</span>
                        </motion.div>
                      ))}
                    </div>
                  </motion.div>

                  {/* Feature Insights */}
                  <motion.div 
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ delay: 0.6 }}
                    whileHover={{ scale: 1.02 }}
                    className="m3-card !bg-tertiary-container/30 backdrop-blur-3xl border-none shadow-2xl shadow-tertiary/10"
                  >
                    <div className="flex items-center gap-3 mb-6">
                       <div className="bg-tertiary/10 p-2 rounded-2xl">
                          <img src="https://img.icons8.com/color/48/globe--v1.png" alt="life" className="w-5 h-5" />
                       </div>
                       <h4 className="font-black text-xs uppercase tracking-[0.2em] text-tertiary">{t.lifeAnalysis}</h4>
                    </div>
                    <div className="space-y-6">
                      <div className="text-center">
                        <p className="text-[10px] uppercase font-black opacity-50 mb-1 tracking-widest">{t.zodiacTrait}</p>
                        <p className="text-3xl font-black text-tertiary tracking-tight">{results.zodiacTrait}</p>
                      </div>
                      <div className="flex justify-center gap-10 border-t border-tertiary/10 pt-6">
                        <div className="text-center">
                          <p className="text-[10px] uppercase font-black opacity-40 mb-1 tracking-widest">{t.planet}</p>
                          <p className="text-base font-black text-on-tertiary-container/80 underline decoration-tertiary/30 underline-offset-4 decoration-2">{results.planet}</p>
                        </div>
                      </div>
                    </div>
                  </motion.div>

                  {/* Detailed Counters */}
                  <div className="grid grid-cols-2 gap-3">
                    <div className="bg-surface-variant p-4 rounded-3xl text-center shadow-sm">
                      <div className="text-[10px] uppercase opacity-60 font-black mb-1">{t.totalWeeks}</div>
                      <div className="text-xl font-bold">{results.totalWeeks.toLocaleString()}</div>
                    </div>
                    <div className="bg-surface-variant p-4 rounded-3xl text-center shadow-sm">
                      <div className="text-[10px] uppercase opacity-60 font-black mb-1">{t.totalDays}</div>
                      <div className="text-xl font-bold">{results.totalDays.toLocaleString()}</div>
                    </div>
                  </div>

                  <div className="grid grid-cols-3 gap-3">
                    <div className="bg-surface-variant p-3 rounded-2xl text-center shadow-sm">
                      <div className="text-[10px] uppercase opacity-60 font-bold">{t.hours}</div>
                      <div className="text-sm font-bold">{results.totalHours.toLocaleString()}</div>
                    </div>
                    <div className="bg-surface-variant p-3 rounded-2xl text-center shadow-sm">
                      <div className="text-[10px] uppercase opacity-60 font-bold">{t.minutes}</div>
                      <div className="text-sm font-bold">{results.totalMinutes.toLocaleString()}</div>
                    </div>
                    <div className="bg-surface-variant p-3 rounded-2xl text-center shadow-sm">
                      <div className="text-[10px] uppercase opacity-60 font-bold">{t.seconds}</div>
                      <div className="text-sm font-bold">{results.totalSeconds.toLocaleString()}</div>
                    </div>
                  </div>
                </motion.section>
              )}
            </motion.div>
          )}

          {activeTab === 'history' && (
            <motion.div
              key="history"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
            >
              <HistoryView history={history} lang={lang} onClear={clearHistory} onDeleteItem={handleDeleteHistoryItem} />
            </motion.div>
          )}

          {activeTab === 'birthdays' && (
            <motion.div
              key="birthdays"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
            >
              <BirthdayView 
                birthdays={birthdays} 
                lang={lang} 
                onAdd={handleAddBirthday} 
                onDelete={handleDeleteBirthday} 
                onEdit={handleEditBirthday}
              />
            </motion.div>
          )}

          {activeTab === 'videos' && (
            <motion.div
              key="videos"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
            >
              <VideoView lang={lang} onVideoViewed={() => addPoints(1)} />
            </motion.div>
          )}
        </AnimatePresence>
        
        {/* Ad Space Placeholder */}
        <div className="mt-8 mb-24 px-2">
          <div className="w-full h-24 bg-primary/5 rounded-[32px] border-2 border-dashed border-primary/20 flex flex-col items-center justify-center relative overflow-hidden group">
            <div className="absolute inset-0 bg-gradient-to-r from-transparent via-primary/5 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-1000" />
            <span className="text-[10px] font-black uppercase tracking-[0.2em] opacity-30 text-primary">Space for Advertisement</span>
            <p className="text-[8px] font-bold opacity-20 uppercase mt-1">High conversion slot</p>
          </div>
        </div>
      </main>

      {/* Birthday Celebration Overlay */}
      <AnimatePresence>
        {showCelebration && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[100] bg-primary/10 backdrop-blur-2xl flex items-center justify-center p-6"
            onClick={() => setShowCelebration(false)}
          >
            <motion.div 
              initial={{ scale: 0.5, y: 50, rotate: -5 }}
              animate={{ scale: 1, y: 0, rotate: 0 }}
              exit={{ scale: 0.5, opacity: 0 }}
              transition={{ type: 'spring', damping: 12 }}
              className="glass-card !bg-white/80 text-on-surface text-center p-12 max-w-sm shadow-[0_32px_64px_-16px_rgba(0,0,0,0.2)] relative overflow-hidden border-none"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="absolute inset-0 pointer-events-none">
                <motion.div 
                  animate={{ rotate: 360 }}
                  transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
                  className="absolute -top-24 -right-24 w-48 h-48 bg-primary/5 rounded-full blur-3xl"
                />
              </div>
              
              <motion.div 
                animate={{ y: [0, -10, 0], rotate: [0, 10, -10, 0] }}
                transition={{ duration: 4, repeat: Infinity }}
                className="text-8xl mb-8 select-none"
              >
                🎂
              </motion.div>
              
              <h2 className="text-4xl font-black mb-4 text-primary tracking-tight leading-none">
                {t.happyBirthday}
              </h2>
              <p className="text-sm font-black uppercase tracking-[0.2em] text-outline/60 mb-8 max-w-[200px] mx-auto leading-relaxed">
                {user?.first_name ? `${user.first_name}, ` : ''}{t.celebrate} {t.daysLeft} 0!
              </p>
              
              <motion.button 
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => setShowCelebration(false)}
                className="m3-button w-full shadow-2xl shadow-primary/40"
              >
                {t.celebrate} 🎉
              </motion.button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Bottom Nav */}
      <nav className="fixed bottom-0 left-0 right-0 max-w-lg mx-auto glass-nav px-8 py-4 pb-10 flex justify-between items-center z-50 rounded-t-[40px]">
        <NavButton 
          active={activeTab === 'calculate'} 
          icon={<img src="https://img.icons8.com/color/96/calculator--v1.png" alt="calc" referrerPolicy="no-referrer" className="w-7 h-7" />} 
          label={t.calculate} 
          onClick={() => setActiveTab('calculate')} 
        />
        <NavButton 
          active={activeTab === 'history'} 
          icon={<img src="https://img.icons8.com/color/96/time-machine.png" alt="history" referrerPolicy="no-referrer" className="w-7 h-7" />} 
          label={t.history} 
          onClick={() => setActiveTab('history')} 
        />
        <NavButton 
          active={activeTab === 'birthdays'} 
          icon={<img src="https://img.icons8.com/color/96/birthday-cake.png" alt="cake" referrerPolicy="no-referrer" className="w-7 h-7" />} 
          label={t.birthdays} 
          onClick={() => setActiveTab('birthdays')} 
        />
        <NavButton 
          active={activeTab === 'videos'} 
          icon={<img src="https://img.icons8.com/color/96/youtube-play.png" alt="videos" referrerPolicy="no-referrer" className="w-7 h-7" />} 
          label={t.videos} 
          onClick={() => setActiveTab('videos')} 
        />
      </nav>

      {/* Profile Modal */}
      <AnimatePresence>
        {showProfile && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[110] bg-black/40 backdrop-blur-sm flex items-end justify-center"
            onClick={() => setShowProfile(false)}
          >
            <motion.div 
              initial={{ y: 300 }}
              animate={{ y: 0 }}
              exit={{ y: 500 }}
              transition={{ type: 'spring', damping: 25, stiffness: 200 }}
              className="bg-surface w-full max-w-lg rounded-t-[48px] p-8 pb-12 shadow-2xl relative"
              onClick={e => e.stopPropagation()}
            >
              <div className="w-12 h-1.5 bg-outline/20 rounded-full mx-auto mb-8" />
              
              <div className="flex flex-col items-center text-center w-full">
                <div className="w-28 h-28 rounded-full border-4 border-primary/20 p-1 mb-4 overflow-hidden shadow-2xl bg-white">
                  {user?.photo_url ? (
                    <img src={user.photo_url} alt="Profile" className="w-full h-full rounded-full object-cover" />
                  ) : (
                    <div className="w-full h-full rounded-full bg-primary/10 flex items-center justify-center">
                       <img src="https://img.icons8.com/color/96/user.png" alt="user" className="w-12 h-12 opacity-50" />
                    </div>
                  )}
                </div>
                
                <div className="flex items-center gap-2 mb-1">
                   <h2 className="text-3xl font-black tracking-tight">{user?.first_name} {user?.last_name || ''}</h2>
                   {user?.is_premium && (
                     <div className="bg-primary/10 text-primary p-1 rounded-md">
                        <img src="https://img.icons8.com/color/48/verified-badge.png" alt="verified" referrerPolicy="no-referrer" className="w-4 h-4" />
                     </div>
                   )}
                </div>
                <p className="text-outline font-mono text-sm mb-8">@{user?.username || t.notSet}</p>
                
                <div className="grid grid-cols-1 gap-4 w-full mb-8">
                  <div className="flex items-center gap-4 bg-white/40 p-4 rounded-[28px] border border-white/40">
                    <div className="bg-primary/10 p-3 rounded-2xl text-primary font-bold">
                       <img src="https://img.icons8.com/color/48/id-card.png" alt="id" className="w-5 h-5" />
                    </div>
                    <div className="text-left">
                       <p className="text-[10px] font-black uppercase opacity-40 leading-none mb-1">{t.id}</p>
                       <p className="font-bold font-mono">{user?.id}</p>
                    </div>
                  </div>

                  <div className="flex items-center gap-4 bg-white/40 p-4 rounded-[28px] border border-white/40">
                    <div className="bg-primary/10 p-3 rounded-2xl text-primary font-bold">
                       <img src="https://img.icons8.com/color/48/language.png" alt="lang" className="w-5 h-5" />
                    </div>
                    <div className="text-left">
                       <p className="text-[10px] font-black uppercase opacity-40 leading-none mb-1">{t.language}</p>
                       <p className="font-bold">{user?.language_code?.toUpperCase() || 'EN'}</p>
                    </div>
                  </div>

                  <div className="flex items-center gap-4 bg-white/40 p-4 rounded-[28px] border border-white/40">
                    <div className="bg-primary/10 p-3 rounded-2xl text-primary font-bold">
                       <img src="https://img.icons8.com/color/48/at-sign.png" alt="at" referrerPolicy="no-referrer" className="w-5 h-5" />
                    </div>
                    <div className="text-left">
                       <p className="text-[10px] font-black uppercase opacity-40 leading-none mb-1">{t.username}</p>
                       <p className="font-bold">@{user?.username || t.notSet}</p>
                    </div>
                  </div>
                </div>
                
                {/* Points Section */}
                <div className="bg-primary text-on-primary p-6 rounded-[32px] w-full mb-8 flex items-center justify-between shadow-xl shadow-primary/20">
                  <div className="text-left">
                    <p className="text-xs font-black uppercase tracking-widest opacity-70 mb-1">{t.totalPoints}</p>
                    <h3 className="text-4xl font-black">{userPoints.toLocaleString()}</h3>
                  </div>
                  <button 
                    onClick={() => setShowWithdrawModal(true)}
                    className="bg-white/20 hover:bg-white/30 p-4 rounded-2xl backdrop-blur-md transition-colors"
                  >
                    <img src="https://img.icons8.com/color/48/get-cash.png" alt="withdraw" className="w-8 h-8 brightness-200" />
                  </button>
                </div>

                {/* Withdrawals List */}
                <div className="w-full mb-8">
                   <h4 className="text-[10px] font-black uppercase opacity-40 text-left ml-4 mb-2 tracking-[0.2em]">{t.withdrawals}</h4>
                   {user?.id && <UserWithdrawalsList lang={lang} userId={user.id.toString()} />}
                </div>

                <div className="w-full">
                  <button 
                    onClick={() => setShowProfile(false)}
                    className="m3-button w-full !bg-primary/10 !text-primary !shadow-none border border-primary/20"
                  >
                     {t.cancel}
                  </button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {showAdmin && (
          <AdminPanel lang={lang} onClose={() => setShowAdmin(false)} />
        )}
      </AnimatePresence>

      <AnimatePresence>
        {showWithdrawModal && user?.id && (
          <WithdrawModal 
            lang={lang} 
            userId={user.id.toString()} 
            username={user.username || 'user'} 
            currentPoints={userPoints} 
            onClose={() => setShowWithdrawModal(false)} 
          />
        )}
      </AnimatePresence>

      {/* Confirmation Dialog */}
      <ConfirmDialog 
        isOpen={confirmData?.isOpen || false}
        title={confirmData?.title || ''}
        message={confirmData?.message}
        onConfirm={confirmData?.action || (() => {})}
        onCancel={() => {
          setConfirmData(null);
          webApp?.HapticFeedback?.selectionChanged();
        }}
        lang={lang}
      />
    </div>
  );
}

function NavButton({ active, icon, label, onClick }: { active: boolean, icon: any, label: string, onClick: () => void }) {
  const handleClick = () => {
    playSound('tab');
    onClick();
  };

  return (
    <button 
      onClick={handleClick}
      className={cn(
        "flex flex-col items-center gap-1.5 transition-all duration-500 outline-none relative",
        active ? "text-primary translate-y-[-4px]" : "text-outline opacity-40 hover:opacity-100"
      )}
    >
      <div className={cn(
        "w-16 h-8 rounded-full transition-all duration-500 flex items-center justify-center",
        active ? "bg-primary/10 shadow-sm" : "bg-transparent"
      )}>
        {icon}
      </div>
      <span className={cn(
        "text-[10px] uppercase tracking-[0.1em] font-black transition-all duration-300",
        active ? "opacity-100" : "opacity-0 scale-75"
      )}>
        {label}
      </span>
      {active && (
        <motion.div 
          layoutId="nav-dot"
          className="absolute -bottom-2 w-1 h-1 bg-primary rounded-full"
        />
      )}
    </button>
  );
}
